import 'package:flutter/material.dart';
import 'dart:math';

// ─── MAIN ────────────────────────────────────────────────────────────────────

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppStateWidget(
      child: Builder(
        builder: (ctx) => MaterialApp(
          title: 'FitTrack',
          debugShowCheckedModeBanner: false,
          theme: _buildTheme(),
          initialRoute: '/login',
          routes: {
            '/login': (_) => const LoginScreen(),
            '/register': (_) => const RegisterScreen(),
            '/main': (_) => const MainShell(),
            '/profile': (_) => const ProfileScreen(),
            '/history': (_) => const HistoryScreen(),
            '/create-routine': (_) => const CreateRoutineScreen(),
          },
          onGenerateRoute: (settings) {
            if (settings.name == '/active-session') {
              return MaterialPageRoute(
                builder: (_) =>
                    ActiveSessionScreen(rutina: settings.arguments as Rutina),
              );
            }
            if (settings.name == '/edit-routine') {
              return MaterialPageRoute(
                builder: (_) =>
                    EditRoutineScreen(rutina: settings.arguments as Rutina),
              );
            }
            return null;
          },
        ),
      ),
    );
  }
}

// ─── COLORS & THEME ──────────────────────────────────────────────────────────

const Color kBackground = Color(0xFF1A1A1A);
const Color kSurface = Color(0xFF2A2A2A);
const Color kSurfaceLight = Color(0xFF333333);
const Color kOrange = Color(0xFFF97316);
const Color kOrangeDark = Color(0xFFEA580C);
const Color kTextPrimary = Color(0xFFFFFFFF);
const Color kTextSecondary = Color(0xFF9CA3AF);
const Color kTextMuted = Color(0xFF6B7280);
const Color kSuccess = Color(0xFF22C55E);
const Color kDivider = Color(0xFF3A3A3A);

ThemeData _buildTheme() => ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: kBackground,
      primaryColor: kOrange,
      colorScheme: const ColorScheme.dark(primary: kOrange, surface: kSurface),
      appBarTheme:
          const AppBarTheme(backgroundColor: kBackground, elevation: 0),
      bottomNavigationBarTheme:
          const BottomNavigationBarThemeData(backgroundColor: kSurface),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: kOrange,
          foregroundColor: kTextPrimary,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: kSurface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: kDivider),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: kDivider),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: kOrange),
        ),
        labelStyle: const TextStyle(color: kTextSecondary),
        hintStyle: const TextStyle(color: kTextMuted),
      ),
    );

// ─── MODELS ──────────────────────────────────────────────────────────────────

class Usuario {
  final String id;
  String nombre;
  String email;
  String contrasena;
  double altura;
  double peso;
  String objetivoFitness;
  double imcActual;
  final DateTime fechaCreacion;

  Usuario({
    required this.id,
    required this.nombre,
    required this.email,
    required this.contrasena,
    required this.altura,
    required this.peso,
    required this.objetivoFitness,
    required this.fechaCreacion,
  }) : imcActual = peso / pow(altura / 100, 2);

  double calcularIMC() => peso / pow(altura / 100, 2);

  Usuario copyWith(
      {String? nombre,
      String? email,
      double? peso,
      double? altura,
      String? objetivoFitness}) {
    return Usuario(
      id: id,
      nombre: nombre ?? this.nombre,
      email: email ?? this.email,
      contrasena: contrasena,
      altura: altura ?? this.altura,
      peso: peso ?? this.peso,
      objetivoFitness: objetivoFitness ?? this.objetivoFitness,
      fechaCreacion: fechaCreacion,
    );
  }
}

class Ejercicio {
  final String id;
  final String nombre;
  final String grupoMuscular;
  final String dificultad;
  final String descripcion;
  final IconData icono;

  const Ejercicio({
    required this.id,
    required this.nombre,
    required this.grupoMuscular,
    required this.dificultad,
    required this.descripcion,
    required this.icono,
  });
}

class Rutina {
  final String id;
  String nombre;
  final String idUsuario;
  List<RutinaEjercicio> ejercicios;
  final DateTime fechaCreacion;

  Rutina({
    required this.id,
    required this.nombre,
    required this.idUsuario,
    required this.ejercicios,
    required this.fechaCreacion,
  });

  Rutina copyWith({String? nombre, List<RutinaEjercicio>? ejercicios}) =>
      Rutina(
        id: id,
        nombre: nombre ?? this.nombre,
        idUsuario: idUsuario,
        ejercicios: ejercicios ?? List.from(this.ejercicios),
        fechaCreacion: fechaCreacion,
      );
}

class RutinaEjercicio {
  final String id;
  final String idEjercicio;
  int series;
  int repeticiones;
  double peso;

  RutinaEjercicio({
    required this.id,
    required this.idEjercicio,
    required this.series,
    required this.repeticiones,
    required this.peso,
  });

  RutinaEjercicio copyWith({int? series, int? repeticiones, double? peso}) =>
      RutinaEjercicio(
        id: id,
        idEjercicio: idEjercicio,
        series: series ?? this.series,
        repeticiones: repeticiones ?? this.repeticiones,
        peso: peso ?? this.peso,
      );
}

class Sesion {
  final String id;
  final String idRutina;
  final String idUsuario;
  final DateTime fecha;
  final DateTime horaInicio;
  DateTime? horaFin;
  int duracionMinutos;
  List<SetRealizado> sets;
  String nombreRutina;

  Sesion({
    required this.id,
    required this.idRutina,
    required this.idUsuario,
    required this.fecha,
    required this.horaInicio,
    this.horaFin,
    required this.duracionMinutos,
    required this.sets,
    required this.nombreRutina,
  });
}

class SetRealizado {
  final String id;
  final String idEjercicio;
  final String nombreEjercicio;
  final int numSerie;
  double pesoReal;
  int repsReales;
  bool completado;

  SetRealizado({
    required this.id,
    required this.idEjercicio,
    required this.nombreEjercicio,
    required this.numSerie,
    required this.pesoReal,
    required this.repsReales,
    required this.completado,
  });
}

// ─── HARDCODED DATA ───────────────────────────────────────────────────────────

final List<Ejercicio> ejerciciosCatalogo = const [
  Ejercicio(
      id: 'e1',
      nombre: 'Press de Banca',
      grupoMuscular: 'Pecho',
      dificultad: 'Intermedio',
      descripcion: 'Ejercicio compuesto para pecho.',
      icono: Icons.fitness_center),
  Ejercicio(
      id: 'e2',
      nombre: 'Sentadilla',
      grupoMuscular: 'Piernas',
      dificultad: 'Intermedio',
      descripcion: 'Ejercicio rey para piernas.',
      icono: Icons.directions_run),
  Ejercicio(
      id: 'e3',
      nombre: 'Peso Muerto',
      grupoMuscular: 'Piernas',
      dificultad: 'Avanzado',
      descripcion: 'Cadena posterior completa.',
      icono: Icons.arrow_upward),
  Ejercicio(
      id: 'e4',
      nombre: 'Dominadas',
      grupoMuscular: 'Espalda',
      dificultad: 'Intermedio',
      descripcion: 'Espalda con peso corporal.',
      icono: Icons.expand_less),
  Ejercicio(
      id: 'e5',
      nombre: 'Press Militar',
      grupoMuscular: 'Hombros',
      dificultad: 'Intermedio',
      descripcion: 'Press vertical para hombros.',
      icono: Icons.sports_gymnastics),
  Ejercicio(
      id: 'e6',
      nombre: 'Curl de Bíceps',
      grupoMuscular: 'Bíceps',
      dificultad: 'Principiante',
      descripcion: 'Ejercicio aislado para bíceps.',
      icono: Icons.sports_martial_arts),
  Ejercicio(
      id: 'e7',
      nombre: 'Extensión Tríceps',
      grupoMuscular: 'Tríceps',
      dificultad: 'Principiante',
      descripcion: 'Ejercicio aislado para tríceps.',
      icono: Icons.back_hand),
  Ejercicio(
      id: 'e8',
      nombre: 'Aperturas Mancuernas',
      grupoMuscular: 'Pecho',
      dificultad: 'Principiante',
      descripcion: 'Apertura para pecho.',
      icono: Icons.open_in_full),
  Ejercicio(
      id: 'e9',
      nombre: 'Fondos en Paralelas',
      grupoMuscular: 'Tríceps',
      dificultad: 'Intermedio',
      descripcion: 'Fondos para tríceps y pecho.',
      icono: Icons.vertical_align_bottom),
  Ejercicio(
      id: 'e10',
      nombre: 'Remo con Barra',
      grupoMuscular: 'Espalda',
      dificultad: 'Intermedio',
      descripcion: 'Tirón horizontal para espalda.',
      icono: Icons.rowing),
  Ejercicio(
      id: 'e11',
      nombre: 'Plancha',
      grupoMuscular: 'Core',
      dificultad: 'Principiante',
      descripcion: 'Ejercicio isométrico de core.',
      icono: Icons.horizontal_rule),
  Ejercicio(
      id: 'e12',
      nombre: 'Zancadas',
      grupoMuscular: 'Piernas',
      dificultad: 'Principiante',
      descripcion: 'Ejercicio unilateral para piernas.',
      icono: Icons.transfer_within_a_station),
  Ejercicio(
      id: 'e13',
      nombre: 'Elevaciones Laterales',
      grupoMuscular: 'Hombros',
      dificultad: 'Principiante',
      descripcion: 'Ejercicio aislado para deltoides medio.',
      icono: Icons.expand),
];

const List<String> categorias = [
  'Todos',
  'Pecho',
  'Piernas',
  'Espalda',
  'Hombros',
  'Bíceps',
  'Tríceps',
  'Core'
];

final Usuario usuarioHardcoded = Usuario(
  id: 'u1',
  nombre: 'Gael Lapeyre',
  email: 'gael@fittrack.com',
  contrasena: '123456',
  peso: 68.0,
  altura: 174.0,
  objetivoFitness: 'ganar_musculo',
  fechaCreacion: DateTime(2026, 1, 1),
);

List<Rutina> _buildRutinasHardcoded() => [
      Rutina(
        id: 'r1',
        nombre: 'Pecho & Tríceps',
        idUsuario: 'u1',
        fechaCreacion: DateTime(2026, 1, 15),
        ejercicios: [
          RutinaEjercicio(
              id: 're1',
              idEjercicio: 'e1',
              series: 3,
              repeticiones: 10,
              peso: 60),
          RutinaEjercicio(
              id: 're2',
              idEjercicio: 'e8',
              series: 3,
              repeticiones: 12,
              peso: 15),
          RutinaEjercicio(
              id: 're3',
              idEjercicio: 'e9',
              series: 3,
              repeticiones: 10,
              peso: 0),
          RutinaEjercicio(
              id: 're4',
              idEjercicio: 'e7',
              series: 3,
              repeticiones: 12,
              peso: 20),
        ],
      ),
      Rutina(
        id: 'r2',
        nombre: 'Espalda & Bíceps',
        idUsuario: 'u1',
        fechaCreacion: DateTime(2026, 1, 16),
        ejercicios: [
          RutinaEjercicio(
              id: 're5',
              idEjercicio: 'e4',
              series: 4,
              repeticiones: 8,
              peso: 0),
          RutinaEjercicio(
              id: 're6',
              idEjercicio: 'e10',
              series: 3,
              repeticiones: 10,
              peso: 50),
          RutinaEjercicio(
              id: 're7',
              idEjercicio: 'e6',
              series: 3,
              repeticiones: 12,
              peso: 15),
        ],
      ),
      Rutina(
        id: 'r3',
        nombre: 'Piernas & Core',
        idUsuario: 'u1',
        fechaCreacion: DateTime(2026, 1, 17),
        ejercicios: [
          RutinaEjercicio(
              id: 're8',
              idEjercicio: 'e2',
              series: 4,
              repeticiones: 8,
              peso: 80),
          RutinaEjercicio(
              id: 're9',
              idEjercicio: 'e3',
              series: 3,
              repeticiones: 6,
              peso: 90),
          RutinaEjercicio(
              id: 're10',
              idEjercicio: 'e12',
              series: 3,
              repeticiones: 12,
              peso: 20),
          RutinaEjercicio(
              id: 're11',
              idEjercicio: 'e11',
              series: 3,
              repeticiones: 60,
              peso: 0),
        ],
      ),
      Rutina(
        id: 'r4',
        nombre: 'Hombros & Trapecios',
        idUsuario: 'u1',
        fechaCreacion: DateTime(2026, 1, 18),
        ejercicios: [
          RutinaEjercicio(
              id: 're12',
              idEjercicio: 'e5',
              series: 3,
              repeticiones: 10,
              peso: 40),
          RutinaEjercicio(
              id: 're13',
              idEjercicio: 'e13',
              series: 3,
              repeticiones: 12,
              peso: 10),
        ],
      ),
    ];

List<Sesion> _buildHistorialHardcoded() {
  final now = DateTime.now();
  SetRealizado sr(String id, String eId, String nombre, int serie, double kg,
          int reps) =>
      SetRealizado(
          id: id,
          idEjercicio: eId,
          nombreEjercicio: nombre,
          numSerie: serie,
          pesoReal: kg,
          repsReales: reps,
          completado: true);

  return [
    Sesion(
      id: 's1',
      idRutina: 'r1',
      idUsuario: 'u1',
      nombreRutina: 'Pecho & Tríceps',
      fecha: now.subtract(const Duration(days: 2)),
      horaInicio: now.subtract(const Duration(days: 2, hours: 1)),
      horaFin: now.subtract(const Duration(days: 2)),
      duracionMinutos: 45,
      sets: [
        sr('sr1', 'e1', 'Press de Banca', 1, 60, 10),
        sr('sr2', 'e1', 'Press de Banca', 2, 60, 10),
        sr('sr3', 'e1', 'Press de Banca', 3, 60, 9),
        sr('sr4', 'e8', 'Aperturas Mancuernas', 1, 15, 12),
        sr('sr5', 'e9', 'Fondos en Paralelas', 1, 0, 10),
      ],
    ),
    Sesion(
      id: 's2',
      idRutina: 'r3',
      idUsuario: 'u1',
      nombreRutina: 'Piernas & Core',
      fecha: now.subtract(const Duration(days: 4)),
      horaInicio: now.subtract(const Duration(days: 4, hours: 1)),
      horaFin: now.subtract(const Duration(days: 4)),
      duracionMinutos: 60,
      sets: [
        sr('sr6', 'e2', 'Sentadilla', 1, 80, 8),
        sr('sr7', 'e2', 'Sentadilla', 2, 80, 8),
        sr('sr8', 'e3', 'Peso Muerto', 1, 90, 6),
      ],
    ),
    Sesion(
      id: 's3',
      idRutina: 'r2',
      idUsuario: 'u1',
      nombreRutina: 'Espalda & Bíceps',
      fecha: now.subtract(const Duration(days: 6)),
      horaInicio: now.subtract(const Duration(days: 6, hours: 1)),
      horaFin: now.subtract(const Duration(days: 6)),
      duracionMinutos: 50,
      sets: [
        sr('sr9', 'e4', 'Dominadas', 1, 0, 8),
        sr('sr10', 'e4', 'Dominadas', 2, 0, 7),
        sr('sr11', 'e10', 'Remo con Barra', 1, 50, 10),
      ],
    ),
    Sesion(
      id: 's4',
      idRutina: 'r4',
      idUsuario: 'u1',
      nombreRutina: 'Hombros & Trapecios',
      fecha: now.subtract(const Duration(days: 9)),
      horaInicio: now.subtract(const Duration(days: 9, hours: 1)),
      horaFin: now.subtract(const Duration(days: 9)),
      duracionMinutos: 40,
      sets: [
        sr('sr12', 'e5', 'Press Militar', 1, 40, 10),
        sr('sr13', 'e5', 'Press Militar', 2, 40, 10),
        sr('sr14', 'e13', 'Elevaciones Laterales', 1, 10, 12),
      ],
    ),
    Sesion(
      id: 's5',
      idRutina: 'r1',
      idUsuario: 'u1',
      nombreRutina: 'Pecho & Tríceps',
      fecha: now.subtract(const Duration(days: 12)),
      horaInicio: now.subtract(const Duration(days: 12, hours: 1)),
      horaFin: now.subtract(const Duration(days: 12)),
      duracionMinutos: 48,
      sets: [
        sr('sr15', 'e1', 'Press de Banca', 1, 57.5, 10),
        sr('sr16', 'e1', 'Press de Banca', 2, 57.5, 10),
        sr('sr17', 'e7', 'Extensión Tríceps', 1, 20, 12),
      ],
    ),
  ];
}

const List<double> pesoEvolucion = [
  65.0,
  65.5,
  66.0,
  66.8,
  67.2,
  67.5,
  68.0,
  68.0
];
const List<double> pressBancaProgresion = [50.0, 52.5, 55.0, 57.5, 60.0, 60.0];
const List<double> sentadillaProgresion = [70.0, 72.5, 75.0, 77.5, 80.0, 80.0];
const List<double> dominadasProgresion = [0.0, 0.0, 2.5, 5.0, 5.0, 7.5];

// ─── APP STATE ────────────────────────────────────────────────────────────────

class AppStateWidget extends StatefulWidget {
  final Widget child;
  const AppStateWidget({Key? key, required this.child}) : super(key: key);

  static _AppStateWidgetState of(BuildContext context) =>
      context.findAncestorStateOfType<_AppStateWidgetState>()!;

  @override
  State<AppStateWidget> createState() => _AppStateWidgetState();
}

class _AppStateWidgetState extends State<AppStateWidget> {
  late Usuario usuario;
  late List<Rutina> rutinas;
  late List<Sesion> historial;

  @override
  void initState() {
    super.initState();
    usuario = usuarioHardcoded;
    rutinas = _buildRutinasHardcoded();
    historial = _buildHistorialHardcoded();
  }

  void updateUsuario(Usuario u) => setState(() => usuario = u);
  void addRutina(Rutina r) => setState(() => rutinas.add(r));
  void updateRutina(Rutina r) {
    setState(() {
      final idx = rutinas.indexWhere((x) => x.id == r.id);
      if (idx >= 0) rutinas[idx] = r;
    });
  }

  void deleteRutina(String id) =>
      setState(() => rutinas.removeWhere((r) => r.id == id));
  void addSesion(Sesion s) => setState(() => historial.insert(0, s));

  @override
  Widget build(BuildContext context) => widget.child;
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

String formatDate(DateTime date) {
  const weekdays = [
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado',
    'Domingo'
  ];
  const months = [
    'Enero',
    'Febrero',
    'Marzo',
    'Abril',
    'Mayo',
    'Junio',
    'Julio',
    'Agosto',
    'Septiembre',
    'Octubre',
    'Noviembre',
    'Diciembre'
  ];
  return '${weekdays[date.weekday - 1]} ${date.day} de ${months[date.month - 1]}, ${date.year}';
}

Ejercicio? findEjercicio(String id) {
  try {
    return ejerciciosCatalogo.firstWhere((e) => e.id == id);
  } catch (_) {
    return null;
  }
}

String uniqueId() => DateTime.now().microsecondsSinceEpoch.toString();

String _initials(String name) {
  final parts = name.trim().split(' ');
  if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
  return name.substring(0, min(2, name.length)).toUpperCase();
}

String _objetivoLabel(String v) {
  switch (v) {
    case 'bajar_peso':
      return 'Bajar de peso';
    case 'ganar_musculo':
      return 'Ganar músculo';
    default:
      return 'Mantenerme';
  }
}

// ─── LOGIN SCREEN ─────────────────────────────────────────────────────────────

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  void _login() {
    if (!_formKey.currentState!.validate()) return;
    if (_emailCtrl.text.trim() == 'gael@fittrack.com' &&
        _passCtrl.text == '123456') {
      Navigator.pushReplacementNamed(context, '/main');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Email o contraseña incorrectos'),
            backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                        color: kOrange.withOpacity(0.15),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.fitness_center,
                        color: kOrange, size: 44),
                  ),
                  const SizedBox(height: 16),
                  const Text('FitTrack',
                      style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: kTextPrimary)),
                  const SizedBox(height: 6),
                  const Text('Tu compañero de entrenamiento',
                      style: TextStyle(fontSize: 14, color: kTextSecondary)),
                  const SizedBox(height: 40),
                  TextFormField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    style: const TextStyle(color: kTextPrimary),
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      prefixIcon:
                          Icon(Icons.email_outlined, color: kTextSecondary),
                    ),
                    validator: (v) =>
                        (v == null || v.isEmpty) ? 'Ingresá tu email' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _passCtrl,
                    obscureText: _obscure,
                    style: const TextStyle(color: kTextPrimary),
                    decoration: InputDecoration(
                      labelText: 'Contraseña',
                      prefixIcon:
                          const Icon(Icons.lock_outline, color: kTextSecondary),
                      suffixIcon: IconButton(
                        icon: Icon(
                            _obscure
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                            color: kTextSecondary),
                        onPressed: () => setState(() => _obscure = !_obscure),
                      ),
                    ),
                    validator: (v) => (v == null || v.isEmpty)
                        ? 'Ingresá tu contraseña'
                        : null,
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _login,
                      child: const Text('Iniciar sesión',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w600)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextButton(
                    onPressed: () => Navigator.pushNamed(context, '/register'),
                    child: const Text('¿No tenés cuenta? Crear una gratis',
                        style: TextStyle(color: kOrange)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── REGISTER SCREEN ─────────────────────────────────────────────────────────

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _obscure1 = true, _obscure2 = true;
  String _objetivo = 'ganar_musculo';

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  void _register() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pushReplacementNamed(context, '/main');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text('Crear cuenta',
              style:
                  TextStyle(color: kTextPrimary, fontWeight: FontWeight.bold))),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _nameCtrl,
                  style: const TextStyle(color: kTextPrimary),
                  decoration: const InputDecoration(
                    labelText: 'Nombre completo',
                    prefixIcon:
                        Icon(Icons.person_outline, color: kTextSecondary),
                  ),
                  validator: (v) =>
                      (v == null || v.isEmpty) ? 'Ingresá tu nombre' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  style: const TextStyle(color: kTextPrimary),
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    prefixIcon:
                        Icon(Icons.email_outlined, color: kTextSecondary),
                  ),
                  validator: (v) =>
                      (v == null || v.isEmpty) ? 'Ingresá tu email' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _passCtrl,
                  obscureText: _obscure1,
                  style: const TextStyle(color: kTextPrimary),
                  decoration: InputDecoration(
                    labelText: 'Contraseña',
                    prefixIcon:
                        const Icon(Icons.lock_outline, color: kTextSecondary),
                    suffixIcon: IconButton(
                      icon: Icon(
                          _obscure1
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          color: kTextSecondary),
                      onPressed: () => setState(() => _obscure1 = !_obscure1),
                    ),
                  ),
                  validator: (v) => (v == null || v.isEmpty)
                      ? 'Ingresá una contraseña'
                      : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _confirmCtrl,
                  obscureText: _obscure2,
                  style: const TextStyle(color: kTextPrimary),
                  decoration: InputDecoration(
                    labelText: 'Confirmar contraseña',
                    prefixIcon:
                        const Icon(Icons.lock_outline, color: kTextSecondary),
                    suffixIcon: IconButton(
                      icon: Icon(
                          _obscure2
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                          color: kTextSecondary),
                      onPressed: () => setState(() => _obscure2 = !_obscure2),
                    ),
                  ),
                  validator: (v) => v != _passCtrl.text
                      ? 'Las contraseñas no coinciden'
                      : null,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: _objetivo,
                  dropdownColor: kSurface,
                  style: const TextStyle(color: kTextPrimary),
                  decoration:
                      const InputDecoration(labelText: 'Objetivo de fitness'),
                  items: const [
                    DropdownMenuItem(
                        value: 'bajar_peso', child: Text('Bajar de peso')),
                    DropdownMenuItem(
                        value: 'ganar_musculo', child: Text('Ganar músculo')),
                    DropdownMenuItem(
                        value: 'mantenerse', child: Text('Mantenerme')),
                  ],
                  onChanged: (v) => setState(() => _objetivo = v!),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _register,
                    child: const Text('Crear cuenta',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                ),
                const SizedBox(height: 16),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('¿Ya tenés cuenta? Iniciá sesión',
                      style: TextStyle(color: kOrange)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── MAIN SHELL ───────────────────────────────────────────────────────────────

class MainShell extends StatefulWidget {
  const MainShell({Key? key}) : super(key: key);
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;
  void setTab(int i) => setState(() => _currentIndex = i);

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(onTabChange: setTab),
      const ExerciseCatalogScreen(),
      const RoutinesScreen(),
      const ProgressScreen(),
    ];
    return Scaffold(
      body: screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
        type: BottomNavigationBarType.fixed,
        backgroundColor: kSurface,
        selectedItemColor: kOrange,
        unselectedItemColor: kTextMuted,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Inicio'),
          BottomNavigationBarItem(
              icon: Icon(Icons.fitness_center), label: 'Ejercicios'),
          BottomNavigationBarItem(icon: Icon(Icons.list_alt), label: 'Rutinas'),
          BottomNavigationBarItem(
              icon: Icon(Icons.bar_chart), label: 'Progreso'),
        ],
      ),
    );
  }
}

// ─── HOME SCREEN ──────────────────────────────────────────────────────────────

class HomeScreen extends StatelessWidget {
  final void Function(int) onTabChange;
  const HomeScreen({Key? key, required this.onTabChange}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = AppStateWidget.of(context);
    final usuario = state.usuario;
    final imc = usuario.calcularIMC();

    return Scaffold(
      appBar: AppBar(
        title: const Text('FitTrack',
            style: TextStyle(
                color: kOrange, fontWeight: FontWeight.bold, fontSize: 22)),
        actions: [
          GestureDetector(
            onTap: () => Navigator.pushNamed(context, '/profile'),
            child: Container(
              margin: const EdgeInsets.only(right: 16),
              width: 38,
              height: 38,
              decoration:
                  const BoxDecoration(color: kOrange, shape: BoxShape.circle),
              alignment: Alignment.center,
              child: Text(
                _initials(usuario.nombre),
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('¡Hola, ${usuario.nombre.split(' ').first}! 👋',
                style: const TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: kTextPrimary)),
            const SizedBox(height: 4),
            const Text('¿Listo para entrenar hoy?',
                style: TextStyle(color: kTextSecondary, fontSize: 14)),
            const SizedBox(height: 20),

            // Stats card
            Container(
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  _StatItem(label: 'IMC', value: imc.toStringAsFixed(1)),
                  Container(width: 1, height: 40, color: kDivider),
                  _StatItem(label: 'Peso', value: '${usuario.peso} kg'),
                  Container(width: 1, height: 40, color: kDivider),
                  _StatItem(
                      label: 'Altura', value: '${usuario.altura.toInt()} cm'),
                ],
              ),
            ),
            const SizedBox(height: 20),

            const Text('Progreso de peso',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: kTextPrimary)),
            const SizedBox(height: 8),
            Container(
              height: 110,
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              child: CustomPaint(
                painter: MiniBarChartPainter(data: pesoEvolucion.sublist(4)),
                size: Size.infinite,
              ),
            ),
            const SizedBox(height: 20),

            const Text('Acciones rápidas',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: kTextPrimary)),
            const SizedBox(height: 8),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.7,
              children: [
                _QuickActionCard(
                  icon: Icons.play_arrow,
                  label: 'Iniciar Entrenamiento',
                  highlight: true,
                  onTap: () => onTabChange(2),
                ),
                _QuickActionCard(
                  icon: Icons.history,
                  label: 'Historial',
                  onTap: () => Navigator.pushNamed(context, '/history'),
                ),
                _QuickActionCard(
                  icon: Icons.list_alt,
                  label: 'Rutinas',
                  onTap: () => onTabChange(2),
                ),
                _QuickActionCard(
                  icon: Icons.person,
                  label: 'Perfil',
                  onTap: () => Navigator.pushNamed(context, '/profile'),
                ),
              ],
            ),
            const SizedBox(height: 20),

            const Text('Rutina sugerida hoy',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: kTextPrimary)),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                        color: kOrange.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10)),
                    child: const Icon(Icons.fitness_center,
                        color: kOrange, size: 26),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Pecho & Tríceps',
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: kTextPrimary)),
                        SizedBox(height: 2),
                        Text('4 ejercicios · ~45 min',
                            style:
                                TextStyle(fontSize: 12, color: kTextSecondary)),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      final rutinas = AppStateWidget.of(context).rutinas;
                      final rutina = rutinas.firstWhere((r) => r.id == 'r1',
                          orElse: () => rutinas.first);
                      Navigator.pushNamed(context, '/active-session',
                          arguments: rutina);
                    },
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10)),
                    child: const Text('Comenzar'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  const _StatItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Column(
          children: [
            Text(value,
                style: const TextStyle(
                    fontSize: 17, fontWeight: FontWeight.bold, color: kOrange)),
            const SizedBox(height: 4),
            Text(label,
                style: const TextStyle(fontSize: 12, color: kTextSecondary)),
          ],
        ),
      );
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool highlight;
  final VoidCallback onTap;
  const _QuickActionCard({
    required this.icon,
    required this.label,
    required this.onTap,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: highlight ? kOrange : kSurface,
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(icon, color: highlight ? Colors.white : kOrange, size: 26),
              const SizedBox(width: 8),
              Expanded(
                child: Text(label,
                    style: TextStyle(
                        color: highlight ? Colors.white : kTextPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w500)),
              ),
            ],
          ),
        ),
      );
}

// ─── EXERCISE CATALOG SCREEN ──────────────────────────────────────────────────

class ExerciseCatalogScreen extends StatefulWidget {
  const ExerciseCatalogScreen({Key? key}) : super(key: key);
  @override
  State<ExerciseCatalogScreen> createState() => _ExerciseCatalogScreenState();
}

class _ExerciseCatalogScreenState extends State<ExerciseCatalogScreen> {
  String _selectedCategory = 'Todos';
  String _searchQuery = '';
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  List<Ejercicio> get _filtered => ejerciciosCatalogo.where((e) {
        final matchCat = _selectedCategory == 'Todos' ||
            e.grupoMuscular == _selectedCategory;
        final matchSearch =
            e.nombre.toLowerCase().contains(_searchQuery.toLowerCase());
        return matchCat && matchSearch;
      }).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ejercicios',
            style: TextStyle(color: kTextPrimary, fontWeight: FontWeight.bold)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              controller: _searchCtrl,
              style: const TextStyle(color: kTextPrimary),
              decoration: InputDecoration(
                hintText: 'Buscar ejercicio...',
                prefixIcon: const Icon(Icons.search, color: kTextSecondary),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: kTextSecondary),
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() => _searchQuery = '');
                        })
                    : null,
              ),
              onChanged: (v) => setState(() => _searchQuery = v),
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              itemCount: categorias.length,
              itemBuilder: (ctx, i) {
                final cat = categorias[i];
                final selected = cat == _selectedCategory;
                return GestureDetector(
                  onTap: () => setState(() => _selectedCategory = cat),
                  child: Container(
                    margin: const EdgeInsets.only(right: 8),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: selected ? kOrange : kSurface,
                      borderRadius: BorderRadius.circular(20),
                      border:
                          Border.all(color: selected ? kOrange : kTextMuted),
                    ),
                    alignment: Alignment.center,
                    child: Text(cat,
                        style: TextStyle(
                            color: selected ? Colors.white : kTextSecondary,
                            fontSize: 13)),
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _filtered.length,
              itemBuilder: (ctx, i) => _ExerciseCard(ejercicio: _filtered[i]),
            ),
          ),
        ],
      ),
    );
  }
}

class _ExerciseCard extends StatelessWidget {
  final Ejercicio ejercicio;
  const _ExerciseCard({required this.ejercicio});

  Color _diffColor() {
    switch (ejercicio.dificultad) {
      case 'Principiante':
        return kSuccess;
      case 'Avanzado':
        return Colors.red;
      default:
        return kOrange;
    }
  }

  @override
  Widget build(BuildContext context) {
    final dc = _diffColor();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: kSurface, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
                color: kSurfaceLight, borderRadius: BorderRadius.circular(10)),
            child: Icon(ejercicio.icono, color: kOrange, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(ejercicio.nombre,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: kTextPrimary)),
                const SizedBox(height: 3),
                Text('${ejercicio.grupoMuscular} • ${ejercicio.dificultad}',
                    style:
                        const TextStyle(fontSize: 12, color: kTextSecondary)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: dc.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: dc.withOpacity(0.4)),
            ),
            child: Text(ejercicio.dificultad,
                style: TextStyle(
                    color: dc, fontSize: 11, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}

// ─── ROUTINES SCREEN ──────────────────────────────────────────────────────────

class RoutinesScreen extends StatelessWidget {
  const RoutinesScreen({Key? key}) : super(key: key);

  void _confirmDelete(BuildContext context, String id) {
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: kSurface,
        title: const Text('Eliminar rutina',
            style: TextStyle(color: kTextPrimary)),
        content: const Text('¿Estás seguro que querés eliminar esta rutina?',
            style: TextStyle(color: kTextSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Cancelar',
                  style: TextStyle(color: kTextSecondary))),
          TextButton(
            onPressed: () {
              AppStateWidget.of(context).deleteRutina(id);
              Navigator.pop(c);
            },
            child: const Text('Eliminar', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final rutinas = AppStateWidget.of(context).rutinas;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis Rutinas',
            style: TextStyle(color: kTextPrimary, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.add, color: kOrange),
            onPressed: () => Navigator.pushNamed(context, '/create-routine'),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: kOrange,
        icon: const Icon(Icons.add, color: Colors.white),
        label:
            const Text('Nueva rutina', style: TextStyle(color: Colors.white)),
        onPressed: () => Navigator.pushNamed(context, '/create-routine'),
      ),
      body: rutinas.isEmpty
          ? const Center(
              child: Text('No tenés rutinas. ¡Creá una!',
                  style: TextStyle(color: kTextSecondary, fontSize: 16)))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
              itemCount: rutinas.length,
              itemBuilder: (ctx, i) {
                final rutina = rutinas[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: kSurface, borderRadius: BorderRadius.circular(12)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(rutina.nombre,
                                style: const TextStyle(
                                    fontSize: 17,
                                    fontWeight: FontWeight.bold,
                                    color: kTextPrimary)),
                          ),
                          PopupMenuButton<String>(
                            color: kSurfaceLight,
                            icon: const Icon(Icons.more_vert,
                                color: kTextSecondary),
                            onSelected: (v) {
                              if (v == 'edit')
                                Navigator.pushNamed(ctx, '/edit-routine',
                                    arguments: rutina);
                              if (v == 'delete') _confirmDelete(ctx, rutina.id);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                  value: 'edit',
                                  child: Text('Editar',
                                      style: TextStyle(color: kTextPrimary))),
                              PopupMenuItem(
                                  value: 'delete',
                                  child: Text('Eliminar',
                                      style: TextStyle(color: Colors.red))),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text('${rutina.ejercicios.length} ejercicios',
                          style: const TextStyle(
                              color: kTextSecondary, fontSize: 13)),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.play_arrow, size: 18),
                          label: const Text('Iniciar'),
                          onPressed: () => Navigator.pushNamed(
                              ctx, '/active-session',
                              arguments: rutina),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

// ─── CREATE ROUTINE SCREEN ────────────────────────────────────────────────────

class CreateRoutineScreen extends StatefulWidget {
  const CreateRoutineScreen({Key? key}) : super(key: key);
  @override
  State<CreateRoutineScreen> createState() => _CreateRoutineScreenState();
}

class _CreateRoutineScreenState extends State<CreateRoutineScreen> {
  final _nameCtrl = TextEditingController();
  final List<RutinaEjercicio> _ejercicios = [];

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  void _addEjercicio() {
    showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => _ExercisePickerSheet(
        onPicked: (e) => setState(() => _ejercicios.add(
              RutinaEjercicio(
                  id: uniqueId(),
                  idEjercicio: e.id,
                  series: 3,
                  repeticiones: 10,
                  peso: 0),
            )),
      ),
    );
  }

  void _save() {
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ingresá un nombre para la rutina')));
      return;
    }
    AppStateWidget.of(context).addRutina(Rutina(
      id: uniqueId(),
      nombre: _nameCtrl.text.trim(),
      idUsuario: 'u1',
      ejercicios: List.from(_ejercicios),
      fechaCreacion: DateTime.now(),
    ));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title:
              const Text('Nueva Rutina', style: TextStyle(color: kTextPrimary)),
          actions: [
            TextButton(
                onPressed: _save,
                child: const Text('Guardar',
                    style:
                        TextStyle(color: kOrange, fontWeight: FontWeight.bold)))
          ],
        ),
        body: _RoutineForm(
          nameCtrl: _nameCtrl,
          ejercicios: _ejercicios,
          onAddEjercicio: _addEjercicio,
          onRemoveEjercicio: (idx) => setState(() => _ejercicios.removeAt(idx)),
          onUpdateEjercicio: (idx, re) => setState(() => _ejercicios[idx] = re),
          onSave: _save,
        ),
      );
}

// ─── EDIT ROUTINE SCREEN ──────────────────────────────────────────────────────

class EditRoutineScreen extends StatefulWidget {
  final Rutina rutina;
  const EditRoutineScreen({Key? key, required this.rutina}) : super(key: key);
  @override
  State<EditRoutineScreen> createState() => _EditRoutineScreenState();
}

class _EditRoutineScreenState extends State<EditRoutineScreen> {
  late final TextEditingController _nameCtrl;
  late List<RutinaEjercicio> _ejercicios;

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.rutina.nombre);
    _ejercicios = List.from(widget.rutina.ejercicios);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    super.dispose();
  }

  void _addEjercicio() {
    showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => _ExercisePickerSheet(
        onPicked: (e) => setState(() => _ejercicios.add(
              RutinaEjercicio(
                  id: uniqueId(),
                  idEjercicio: e.id,
                  series: 3,
                  repeticiones: 10,
                  peso: 0),
            )),
      ),
    );
  }

  void _save() {
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ingresá un nombre para la rutina')));
      return;
    }
    AppStateWidget.of(context).updateRutina(widget.rutina.copyWith(
        nombre: _nameCtrl.text.trim(), ejercicios: List.from(_ejercicios)));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Editar Rutina',
              style: TextStyle(color: kTextPrimary)),
          actions: [
            TextButton(
                onPressed: _save,
                child: const Text('Guardar',
                    style:
                        TextStyle(color: kOrange, fontWeight: FontWeight.bold)))
          ],
        ),
        body: _RoutineForm(
          nameCtrl: _nameCtrl,
          ejercicios: _ejercicios,
          onAddEjercicio: _addEjercicio,
          onRemoveEjercicio: (idx) => setState(() => _ejercicios.removeAt(idx)),
          onUpdateEjercicio: (idx, re) => setState(() => _ejercicios[idx] = re),
          onSave: _save,
        ),
      );
}

// Shared form widget for Create & Edit
class _RoutineForm extends StatelessWidget {
  final TextEditingController nameCtrl;
  final List<RutinaEjercicio> ejercicios;
  final VoidCallback onAddEjercicio;
  final void Function(int) onRemoveEjercicio;
  final void Function(int, RutinaEjercicio) onUpdateEjercicio;
  final VoidCallback onSave;

  const _RoutineForm({
    required this.nameCtrl,
    required this.ejercicios,
    required this.onAddEjercicio,
    required this.onRemoveEjercicio,
    required this.onUpdateEjercicio,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: nameCtrl,
            style: const TextStyle(color: kTextPrimary),
            decoration: const InputDecoration(labelText: 'Nombre de la rutina'),
          ),
          const SizedBox(height: 20),
          const Text('Ejercicios',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: kTextPrimary)),
          const SizedBox(height: 8),
          ...ejercicios.asMap().entries.map((entry) {
            final idx = entry.key;
            final re = entry.value;
            final ej = findEjercicio(re.idEjercicio);
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.fromLTRB(12, 8, 4, 12),
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(10)),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                          child: Text(ej?.nombre ?? re.idEjercicio,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: kTextPrimary))),
                      IconButton(
                        icon: const Icon(Icons.delete_outline,
                            color: Colors.red, size: 20),
                        onPressed: () => onRemoveEjercicio(idx),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      _NumberField(
                        label: 'Series',
                        value: re.series,
                        onChanged: (v) =>
                            onUpdateEjercicio(idx, re.copyWith(series: v)),
                      ),
                      _NumberField(
                        label: 'Reps',
                        value: re.repeticiones,
                        onChanged: (v) => onUpdateEjercicio(
                            idx, re.copyWith(repeticiones: v)),
                      ),
                      _NumberField(
                        label: 'Peso (kg)',
                        value: re.peso.toInt(),
                        onChanged: (v) => onUpdateEjercicio(
                            idx, re.copyWith(peso: v.toDouble())),
                      ),
                    ],
                  ),
                ],
              ),
            );
          }).toList(),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            icon: const Icon(Icons.add, color: kOrange),
            label: const Text('Agregar ejercicio',
                style: TextStyle(color: kOrange)),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: kOrange),
              minimumSize: const Size(double.infinity, 44),
            ),
            onPressed: onAddEjercicio,
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
                onPressed: onSave,
                child: const Text('Guardar rutina',
                    style: TextStyle(fontSize: 16))),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _NumberField extends StatelessWidget {
  final String label;
  final int value;
  final void Function(int) onChanged;
  const _NumberField(
      {required this.label, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Expanded(
        child: Column(
          children: [
            Text(label,
                style: const TextStyle(fontSize: 11, color: kTextSecondary)),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GestureDetector(
                  onTap: () {
                    if (value > 0) onChanged(value - 1);
                  },
                  child: Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                        color: kSurfaceLight,
                        borderRadius: BorderRadius.circular(6)),
                    alignment: Alignment.center,
                    child:
                        const Icon(Icons.remove, color: kTextPrimary, size: 14),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text('$value',
                      style: const TextStyle(
                          color: kTextPrimary,
                          fontWeight: FontWeight.bold,
                          fontSize: 14)),
                ),
                GestureDetector(
                  onTap: () => onChanged(value + 1),
                  child: Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                        color: kSurfaceLight,
                        borderRadius: BorderRadius.circular(6)),
                    alignment: Alignment.center,
                    child: const Icon(Icons.add, color: kTextPrimary, size: 14),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
}

class _ExercisePickerSheet extends StatefulWidget {
  final void Function(Ejercicio) onPicked;
  const _ExercisePickerSheet({required this.onPicked});
  @override
  State<_ExercisePickerSheet> createState() => _ExercisePickerSheetState();
}

class _ExercisePickerSheetState extends State<_ExercisePickerSheet> {
  String _query = '';
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = ejerciciosCatalogo
        .where((e) => e.nombre.toLowerCase().contains(_query.toLowerCase()))
        .toList();
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      maxChildSize: 0.92,
      builder: (ctx, scrollCtrl) => Column(
        children: [
          const SizedBox(height: 8),
          Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                  color: kDivider, borderRadius: BorderRadius.circular(2))),
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _ctrl,
              style: const TextStyle(color: kTextPrimary),
              decoration: const InputDecoration(
                hintText: 'Buscar ejercicio...',
                prefixIcon: Icon(Icons.search, color: kTextSecondary),
              ),
              onChanged: (v) => setState(() => _query = v),
            ),
          ),
          Expanded(
            child: ListView.builder(
              controller: scrollCtrl,
              itemCount: filtered.length,
              itemBuilder: (_, i) {
                final e = filtered[i];
                return ListTile(
                  leading: Icon(e.icono, color: kOrange),
                  title: Text(e.nombre,
                      style: const TextStyle(color: kTextPrimary)),
                  subtitle: Text(e.grupoMuscular,
                      style: const TextStyle(color: kTextSecondary)),
                  onTap: () {
                    Navigator.pop(context);
                    widget.onPicked(e);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── ACTIVE SESSION SCREEN ────────────────────────────────────────────────────

class ActiveSessionScreen extends StatefulWidget {
  final Rutina rutina;
  const ActiveSessionScreen({Key? key, required this.rutina}) : super(key: key);
  @override
  State<ActiveSessionScreen> createState() => _ActiveSessionScreenState();
}

class _ActiveSessionScreenState extends State<ActiveSessionScreen> {
  int _currentExIdx = 0;
  late List<List<SetRealizado>> _setsPerExercise;
  late DateTime _startTime;

  @override
  void initState() {
    super.initState();
    _startTime = DateTime.now();
    _setsPerExercise = widget.rutina.ejercicios.map((re) {
      final ej = findEjercicio(re.idEjercicio);
      return List.generate(
          re.series,
          (i) => SetRealizado(
                id: uniqueId(),
                idEjercicio: re.idEjercicio,
                nombreEjercicio: ej?.nombre ?? re.idEjercicio,
                numSerie: i + 1,
                pesoReal: re.peso,
                repsReales: re.repeticiones,
                completado: false,
              ));
    }).toList();
  }

  RutinaEjercicio get _currentRE => widget.rutina.ejercicios[_currentExIdx];
  List<SetRealizado> get _currentSets => _setsPerExercise[_currentExIdx];
  Ejercicio? get _currentEj => findEjercicio(_currentRE.idEjercicio);

  void _finalizarSesion() {
    final endTime = DateTime.now();
    final duracion = endTime.difference(_startTime).inMinutes;
    final allSets = _setsPerExercise.expand((s) => s).toList();

    AppStateWidget.of(context).addSesion(Sesion(
      id: uniqueId(),
      idRutina: widget.rutina.id,
      idUsuario: 'u1',
      fecha: DateTime.now(),
      horaInicio: _startTime,
      horaFin: endTime,
      duracionMinutos: duracion > 0 ? duracion : 1,
      sets: allSets,
      nombreRutina: widget.rutina.nombre,
    ));

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (c) => AlertDialog(
        backgroundColor: kSurface,
        title: const Text('¡Sesión completada! 🎉',
            style: TextStyle(color: kTextPrimary, fontSize: 18)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text('Duración: ${duracion > 0 ? duracion : 1} min',
                style: const TextStyle(color: kTextSecondary)),
            const SizedBox(height: 4),
            Text(
                'Sets completados: ${allSets.where((s) => s.completado).length} / ${allSets.length}',
                style: const TextStyle(color: kTextSecondary)),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.pop(c);
              Navigator.pushNamedAndRemoveUntil(context, '/main', (_) => false);
            },
            child: const Text('Volver al inicio'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.rutina.ejercicios.length;
    final ej = _currentEj;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.rutina.nombre,
            style: const TextStyle(color: kTextPrimary)),
        actions: [
          TextButton(
            onPressed: _finalizarSesion,
            child: const Text('Finalizar',
                style:
                    TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: kSurface,
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text('Ejercicio ${_currentExIdx + 1} de $total',
                textAlign: TextAlign.center,
                style: const TextStyle(color: kTextSecondary, fontSize: 13)),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(ej?.nombre ?? _currentRE.idEjercicio,
                      style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: kTextPrimary)),
                  if (ej != null) ...[
                    const SizedBox(height: 2),
                    Text(ej.grupoMuscular,
                        style: const TextStyle(color: kOrange, fontSize: 14)),
                  ],
                  const SizedBox(height: 20),

                  // Sets table
                  Container(
                    decoration: BoxDecoration(
                        color: kSurface,
                        borderRadius: BorderRadius.circular(12)),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 10),
                          child: Row(
                            children: const [
                              Expanded(
                                  flex: 1,
                                  child: Text('Serie',
                                      style: TextStyle(
                                          color: kTextSecondary,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600))),
                              Expanded(
                                  flex: 2,
                                  child: Text('kg',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: kTextSecondary,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600))),
                              Expanded(
                                  flex: 2,
                                  child: Text('Reps',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: kTextSecondary,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600))),
                              Expanded(
                                  flex: 1,
                                  child: Text('✓',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: kTextSecondary,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600))),
                            ],
                          ),
                        ),
                        const Divider(color: kDivider, height: 1),
                        ..._currentSets.asMap().entries.map((entry) {
                          final si = entry.key;
                          final set = entry.value;
                          return _SetRow(
                            set: set,
                            onToggle: () => setState(() => _currentSets[si]
                                .completado = !_currentSets[si].completado),
                            onPesoChanged: (v) =>
                                setState(() => _currentSets[si].pesoReal = v),
                            onRepsChanged: (v) =>
                                setState(() => _currentSets[si].repsReales = v),
                          );
                        }).toList(),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  Row(
                    children: [
                      if (_currentExIdx > 0) ...[
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: const Icon(Icons.arrow_back,
                                color: kOrange, size: 16),
                            label: const Text('Anterior',
                                style: TextStyle(color: kOrange)),
                            style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: kOrange)),
                            onPressed: () => setState(() => _currentExIdx--),
                          ),
                        ),
                        const SizedBox(width: 12),
                      ],
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: Icon(
                            _currentExIdx < total - 1
                                ? Icons.arrow_forward
                                : Icons.check,
                            size: 16,
                          ),
                          label: Text(_currentExIdx < total - 1
                              ? 'Siguiente'
                              : 'Finalizar'),
                          onPressed: _currentExIdx < total - 1
                              ? () => setState(() => _currentExIdx++)
                              : _finalizarSesion,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SetRow extends StatelessWidget {
  final SetRealizado set;
  final VoidCallback onToggle;
  final void Function(double) onPesoChanged;
  final void Function(int) onRepsChanged;

  const _SetRow({
    required this.set,
    required this.onToggle,
    required this.onPesoChanged,
    required this.onRepsChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: set.completado ? kSuccess.withOpacity(0.08) : Colors.transparent,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text('${set.numSerie}',
                style: const TextStyle(
                    color: kTextPrimary, fontWeight: FontWeight.bold)),
          ),
          Expanded(
            flex: 2,
            child: _InlineSpinner(
              value:
                  set.pesoReal.toStringAsFixed(set.pesoReal % 1 == 0 ? 0 : 1),
              onDecrement: () => onPesoChanged(max(0.0, set.pesoReal - 2.5)),
              onIncrement: () => onPesoChanged(set.pesoReal + 2.5),
            ),
          ),
          Expanded(
            flex: 2,
            child: _InlineSpinner(
              value: '${set.repsReales}',
              onDecrement: () => onRepsChanged(max(1, set.repsReales - 1)),
              onIncrement: () => onRepsChanged(set.repsReales + 1),
            ),
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: GestureDetector(
                onTap: onToggle,
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: set.completado ? kSuccess : kSurfaceLight,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                        color: set.completado ? kSuccess : kTextMuted),
                  ),
                  child: set.completado
                      ? const Icon(Icons.check, color: Colors.white, size: 18)
                      : null,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InlineSpinner extends StatelessWidget {
  final String value;
  final VoidCallback onDecrement;
  final VoidCallback onIncrement;
  const _InlineSpinner(
      {required this.value,
      required this.onDecrement,
      required this.onIncrement});

  @override
  Widget build(BuildContext context) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GestureDetector(
              onTap: onDecrement,
              child: const Icon(Icons.remove_circle_outline,
                  color: kTextSecondary, size: 18)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Text(value,
                style: const TextStyle(
                    color: kTextPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 15)),
          ),
          GestureDetector(
              onTap: onIncrement,
              child: const Icon(Icons.add_circle_outline,
                  color: kTextSecondary, size: 18)),
        ],
      );
}

// ─── HISTORY SCREEN ───────────────────────────────────────────────────────────

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final historial = AppStateWidget.of(context).historial;
    final sorted = List<Sesion>.from(historial)
      ..sort((a, b) => b.fecha.compareTo(a.fecha));

    return Scaffold(
      appBar: AppBar(
          title: const Text('Historial',
              style:
                  TextStyle(color: kTextPrimary, fontWeight: FontWeight.bold))),
      body: sorted.isEmpty
          ? const Center(
              child: Text('Sin sesiones registradas.',
                  style: TextStyle(color: kTextSecondary, fontSize: 16)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: sorted.length,
              itemBuilder: (ctx, i) {
                final s = sorted[i];
                return GestureDetector(
                  onTap: () => _showDetail(ctx, s),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        color: kSurface,
                        borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      children: [
                        Container(
                          width: 46,
                          height: 46,
                          decoration: BoxDecoration(
                              color: kSurfaceLight,
                              borderRadius: BorderRadius.circular(10)),
                          child: const Icon(Icons.fitness_center,
                              color: kOrange, size: 22),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(s.nombreRutina,
                                  style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                      color: kTextPrimary)),
                              const SizedBox(height: 3),
                              Text(formatDate(s.fecha),
                                  style: const TextStyle(
                                      fontSize: 12, color: kTextSecondary)),
                              const SizedBox(height: 3),
                              Row(
                                children: [
                                  const Icon(Icons.timer_outlined,
                                      size: 12, color: kTextMuted),
                                  const SizedBox(width: 3),
                                  Text('${s.duracionMinutos} min',
                                      style: const TextStyle(
                                          fontSize: 12, color: kTextMuted)),
                                  const SizedBox(width: 12),
                                  const Icon(Icons.bar_chart,
                                      size: 12, color: kTextMuted),
                                  const SizedBox(width: 3),
                                  Text('${s.sets.length} sets',
                                      style: const TextStyle(
                                          fontSize: 12, color: kTextMuted)),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right, color: kTextMuted),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _showDetail(BuildContext context, Sesion s) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kSurface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: kDivider,
                        borderRadius: BorderRadius.circular(2))),
              ),
              const SizedBox(height: 16),
              Text(s.nombreRutina,
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: kTextPrimary)),
              const SizedBox(height: 4),
              Text(formatDate(s.fecha),
                  style: const TextStyle(fontSize: 13, color: kTextSecondary)),
              Text('Duración: ${s.duracionMinutos} min',
                  style: const TextStyle(color: kTextSecondary, fontSize: 13)),
              const SizedBox(height: 16),
              const Text('Sets realizados:',
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: kTextPrimary,
                      fontSize: 15)),
              const SizedBox(height: 8),
              ...s.sets.map((set) => Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        Icon(
                            set.completado
                                ? Icons.check_circle
                                : Icons.radio_button_unchecked,
                            color: set.completado ? kSuccess : kTextMuted,
                            size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                            child: Text(set.nombreEjercicio,
                                style: const TextStyle(
                                    color: kTextPrimary, fontSize: 13))),
                        Text(
                            'Serie ${set.numSerie} · ${set.pesoReal} kg × ${set.repsReales}',
                            style: const TextStyle(
                                color: kTextSecondary, fontSize: 12)),
                      ],
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── PROGRESS SCREEN ─────────────────────────────────────────────────────────

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final usuario = AppStateWidget.of(context).usuario;
    final diff = usuario.peso - pesoEvolucion.first;
    final diffStr =
        diff >= 0 ? '+${diff.toStringAsFixed(1)}' : diff.toStringAsFixed(1);

    return Scaffold(
      appBar: AppBar(
          title: const Text('Progreso',
              style:
                  TextStyle(color: kTextPrimary, fontWeight: FontWeight.bold))),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current weight highlight
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Peso actual',
                          style:
                              TextStyle(color: kTextSecondary, fontSize: 13)),
                      Text('${usuario.peso} kg',
                          style: const TextStyle(
                              color: kTextPrimary,
                              fontSize: 28,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(width: 20),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: diff >= 0
                          ? kSuccess.withOpacity(0.15)
                          : Colors.red.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text('$diffStr kg desde inicio',
                        style: TextStyle(
                            color: diff >= 0 ? kSuccess : Colors.red,
                            fontWeight: FontWeight.bold,
                            fontSize: 13)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            const Text('Evolución de peso',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: kTextPrimary)),
            const SizedBox(height: 8),
            Container(
              height: 180,
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: CustomPaint(
                painter: LineChartPainter(data: pesoEvolucion),
                size: Size.infinite,
              ),
            ),
            const SizedBox(height: 20),

            const Text('Progresión de carga',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: kTextPrimary)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  _LoadBar(
                      label: 'Press de Banca',
                      value: pressBancaProgresion.last,
                      max: 100),
                  const SizedBox(height: 14),
                  _LoadBar(
                      label: 'Sentadilla',
                      value: sentadillaProgresion.last,
                      max: 120),
                  const SizedBox(height: 14),
                  _LoadBar(
                      label: 'Dominadas (+kg)',
                      value: dominadasProgresion.last,
                      max: 20,
                      prefix: '+'),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Streak
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              child: Row(
                children: [
                  const Text('🔥', style: TextStyle(fontSize: 28)),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Racha activa',
                          style:
                              TextStyle(color: kTextSecondary, fontSize: 13)),
                      Text('Hace 12 días seguidos',
                          style: TextStyle(
                              color: kTextPrimary,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _LoadBar extends StatelessWidget {
  final String label;
  final double value;
  final double max;
  final String prefix;
  const _LoadBar(
      {required this.label,
      required this.value,
      required this.max,
      this.prefix = ''});

  @override
  Widget build(BuildContext context) {
    final pct = (value / max).clamp(0.0, 1.0);
    final displayVal = value % 1 == 0
        ? '$prefix${value.toInt()} kg'
        : '$prefix${value.toStringAsFixed(1)} kg';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label,
                style: const TextStyle(color: kTextPrimary, fontSize: 14)),
            Text(displayVal,
                style: const TextStyle(
                    color: kOrange, fontWeight: FontWeight.bold, fontSize: 14)),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: pct,
            backgroundColor: kSurfaceLight,
            valueColor: const AlwaysStoppedAnimation<Color>(kOrange),
            minHeight: 8,
          ),
        ),
      ],
    );
  }
}

// ─── PROFILE SCREEN ───────────────────────────────────────────────────────────

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  TextEditingController? _pesoCtrl;
  TextEditingController? _alturaCtrl;
  String _objetivo = 'ganar_musculo';
  bool _editMode = false;
  bool _initialized = false;

  @override
  void dispose() {
    _pesoCtrl?.dispose();
    _alturaCtrl?.dispose();
    super.dispose();
  }

  void _initControllers(Usuario u) {
    if (!_initialized) {
      _pesoCtrl = TextEditingController(text: u.peso.toString());
      _alturaCtrl = TextEditingController(text: u.altura.toString());
      _objetivo = u.objetivoFitness;
      _initialized = true;
    }
  }

  void _save(Usuario u) {
    final state = AppStateWidget.of(context);
    final updated = u.copyWith(
      peso: double.tryParse(_pesoCtrl?.text ?? '') ?? u.peso,
      altura: double.tryParse(_alturaCtrl?.text ?? '') ?? u.altura,
      objetivoFitness: _objetivo,
    );
    state.updateUsuario(updated);
    setState(() => _editMode = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Perfil actualizado'), backgroundColor: kSuccess),
    );
  }

  void _logout() {
    showDialog(
      context: context,
      builder: (c) => AlertDialog(
        backgroundColor: kSurface,
        title:
            const Text('Cerrar sesión', style: TextStyle(color: kTextPrimary)),
        content: const Text('¿Estás seguro que querés cerrar sesión?',
            style: TextStyle(color: kTextSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c),
              child: const Text('Cancelar',
                  style: TextStyle(color: kTextSecondary))),
          TextButton(
            onPressed: () {
              Navigator.pop(c);
              Navigator.pushNamedAndRemoveUntil(
                  context, '/login', (_) => false);
            },
            child: const Text('Cerrar sesión',
                style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateWidget.of(context);
    final usuario = state.usuario;
    _initControllers(usuario);
    final imc = usuario.calcularIMC();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil',
            style: TextStyle(color: kTextPrimary, fontWeight: FontWeight.bold)),
        actions: [
          TextButton(
            onPressed: () => setState(() => _editMode = !_editMode),
            child: Text(_editMode ? 'Cancelar' : 'Editar',
                style: const TextStyle(color: kOrange)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              width: 80,
              height: 80,
              decoration:
                  const BoxDecoration(color: kOrange, shape: BoxShape.circle),
              alignment: Alignment.center,
              child: Text(_initials(usuario.nombre),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 12),
            Text(usuario.nombre,
                style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: kTextPrimary)),
            const SizedBox(height: 4),
            Text(usuario.email,
                style: const TextStyle(fontSize: 14, color: kTextSecondary)),
            const SizedBox(height: 8),
            Text('Objetivo: ${_objetivoLabel(usuario.objetivoFitness)}',
                style: const TextStyle(fontSize: 13, color: kOrange)),
            const SizedBox(height: 16),

            // Stats row
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: kSurface, borderRadius: BorderRadius.circular(12)),
              child: Row(
                children: [
                  _StatItem(label: 'Peso', value: '${usuario.peso} kg'),
                  Container(width: 1, height: 40, color: kDivider),
                  _StatItem(
                      label: 'Altura', value: '${usuario.altura.toInt()} cm'),
                  Container(width: 1, height: 40, color: kDivider),
                  _StatItem(label: 'IMC', value: imc.toStringAsFixed(1)),
                ],
              ),
            ),
            const SizedBox(height: 20),

            if (_editMode) ...[
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('Editar perfil',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: kTextPrimary)),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _pesoCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                style: const TextStyle(color: kTextPrimary),
                decoration: const InputDecoration(labelText: 'Peso (kg)'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _alturaCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                style: const TextStyle(color: kTextPrimary),
                decoration: const InputDecoration(labelText: 'Altura (cm)'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _objetivo,
                dropdownColor: kSurface,
                style: const TextStyle(color: kTextPrimary),
                decoration: const InputDecoration(labelText: 'Objetivo'),
                items: const [
                  DropdownMenuItem(
                      value: 'bajar_peso', child: Text('Bajar de peso')),
                  DropdownMenuItem(
                      value: 'ganar_musculo', child: Text('Ganar músculo')),
                  DropdownMenuItem(
                      value: 'mantenerse', child: Text('Mantenerme')),
                ],
                onChanged: (v) => setState(() => _objetivo = v!),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => _save(usuario),
                  child: const Text('Guardar cambios',
                      style: TextStyle(fontSize: 16)),
                ),
              ),
              const SizedBox(height: 20),
            ],

            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Cuenta',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: kTextPrimary)),
            ),
            const SizedBox(height: 8),
            _AccountTile(
                icon: Icons.notifications_outlined, label: 'Notificaciones'),
            _AccountTile(icon: Icons.lock_outline, label: 'Privacidad y datos'),
            _AccountTile(
                icon: Icons.download_outlined, label: 'Exportar datos'),
            const SizedBox(height: 8),
            Material(
              color: kSurface,
              borderRadius: BorderRadius.circular(10),
              child: ListTile(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                leading: const Icon(Icons.logout, color: Colors.red),
                title: const Text('Cerrar sesión',
                    style: TextStyle(color: Colors.red)),
                onTap: _logout,
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _AccountTile extends StatelessWidget {
  final IconData icon;
  final String label;
  const _AccountTile({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        child: Material(
          color: kSurface,
          borderRadius: BorderRadius.circular(10),
          child: ListTile(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            leading: Icon(icon, color: kTextSecondary),
            title: Text(label, style: const TextStyle(color: kTextPrimary)),
            trailing: const Icon(Icons.chevron_right, color: kTextMuted),
            onTap: () {},
          ),
        ),
      );
}

// ─── CUSTOM PAINTERS ─────────────────────────────────────────────────────────

class LineChartPainter extends CustomPainter {
  final List<double> data;
  const LineChartPainter({required this.data});

  @override
  void paint(Canvas canvas, Size size) {
    if (data.length < 2) return;
    final minY = data.reduce(min) - 2;
    final maxY = data.reduce(max) + 2;
    final range = maxY - minY;
    if (range <= 0) return;

    double tx(int i) => i * size.width / (data.length - 1);
    double ty(double v) => size.height - ((v - minY) / range) * size.height;

    // Area under curve
    final areaPaint = Paint()..color = kOrange.withOpacity(0.12);
    final areaPath = Path()..moveTo(tx(0), size.height);
    for (int i = 0; i < data.length; i++) areaPath.lineTo(tx(i), ty(data[i]));
    areaPath.lineTo(tx(data.length - 1), size.height);
    areaPath.close();
    canvas.drawPath(areaPath, areaPaint);

    // Line
    final linePaint = Paint()
      ..color = kOrange
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final linePath = Path()..moveTo(tx(0), ty(data[0]));
    for (int i = 1; i < data.length; i++) linePath.lineTo(tx(i), ty(data[i]));
    canvas.drawPath(linePath, linePaint);

    // Points
    for (int i = 0; i < data.length; i++) {
      final pt = Offset(tx(i), ty(data[i]));
      canvas.drawCircle(pt, 4.5, Paint()..color = kOrange);
      canvas.drawCircle(pt, 2.5, Paint()..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(LineChartPainter old) => old.data != data;
}

class MiniBarChartPainter extends CustomPainter {
  final List<double> data;
  const MiniBarChartPainter({required this.data});

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty) return;
    final maxV = data.reduce(max);
    if (maxV <= 0) return;

    final barW = (size.width / data.length) * 0.55;
    final gap = size.width / data.length;
    final paint = Paint()..color = kOrange;

    for (int i = 0; i < data.length; i++) {
      final barH = (data[i] / maxV) * size.height * 0.9;
      final left = i * gap + (gap - barW) / 2;
      canvas.drawRRect(
        RRect.fromLTRBR(left, size.height - barH, left + barW, size.height,
            const Radius.circular(3)),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(MiniBarChartPainter old) => old.data != data;
}
